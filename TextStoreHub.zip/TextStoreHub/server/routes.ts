import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertPromptSchema, type InsertPrompt } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { setupAuth } from "./auth";
import { z } from "zod";

export async function registerRoutes(app: Express) {
  // Set up authentication
  setupAuth(app);

  app.get("/api/prompts", async (_req, res) => {
    const prompts = await storage.getAllPrompts();
    res.json(prompts);
  });

  app.post("/api/prompts", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const promptData = insertPromptSchema.parse(req.body);
      const prompt = await storage.createPrompt({
        ...promptData,
        userId: req.user.id,
      });
      res.json(prompt);
    } catch (err: any) {
      if (err.name === "ZodError") {
        res.status(400).json({ message: fromZodError(err).message });
      } else {
        res.status(500).json({ message: err.message });
      }
    }
  });

  app.post("/api/prompts/import", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const importSchema = z.array(insertPromptSchema);
      const promptsData = importSchema.parse(req.body);
      const results = await Promise.all(
        promptsData.map((promptData) => 
          storage.createPrompt({ ...promptData, userId: req.user.id })
        )
      );
      res.json(results);
    } catch (err: any) {
      if (err.name === "ZodError") {
        res.status(400).json({ message: fromZodError(err).message });
      } else {
        res.status(500).json({ message: err.message });
      }
    }
  });

  app.patch("/api/prompts/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const promptData = insertPromptSchema.parse(req.body);
      const prompt = await storage.updatePrompt(id, {
        ...promptData,
        userId: req.user.id,
      });
      res.json(prompt);
    } catch (err: any) {
      if (err.name === "ZodError") {
        res.status(400).json({ message: fromZodError(err).message });
      } else {
        res.status(404).json({ message: err.message });
      }
    }
  });

  app.delete("/api/prompts/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      await storage.deletePrompt(id);
      res.status(204).end();
    } catch (err: any) {
      res.status(404).json({ message: err.message });
    }
  });

  return createServer(app);
}