import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogTrigger } from "@/components/ui/dialog";
import { Copy, Download, Pencil, Trash } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { CreatePrompt } from "./create-prompt";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { downloadFile } from "@/lib/api";
import type { Prompt } from "@shared/schema";

interface PromptCardProps {
  prompt: Prompt;
}

export function PromptCard({ prompt }: PromptCardProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/prompts/${prompt.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prompts"] });
      toast({
        title: "Prompt deleted",
        description: "The prompt has been successfully deleted.",
      });
    },
  });

  const copyToClipboard = () => {
    navigator.clipboard.writeText(prompt.content);
    toast({
      title: "Copied to clipboard",
      description: "The prompt has been copied to your clipboard.",
    });
  };

  const handleDownload = async () => {
    try {
      if (!prompt.mediaUrl) return;

      const extension = prompt.mediaType === 'image' ? 'jpg' : 'mp4';
      const filename = `${prompt.title.toLowerCase().replace(/\s+/g, '-')}.${extension}`;

      await downloadFile(prompt.mediaUrl, filename);

      toast({
        title: "Download started",
        description: "Your file download has started.",
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Failed to download the file. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="group transition-all hover:shadow-lg dark:hover:shadow-primary/5 hover:-translate-y-1">
      <CardHeader className="space-y-1">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold tracking-tight">{prompt.title}</h2>
          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Dialog open={isEditing} onOpenChange={setIsEditing}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Pencil className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <CreatePrompt existingPrompt={prompt} onClose={() => setIsEditing(false)} />
            </Dialog>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Trash className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Prompt</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete this prompt? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => deleteMutation.mutate()}>
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-muted-foreground">{prompt.content}</p>

        {prompt.mediaUrl && (
          <div className="relative rounded-lg overflow-hidden">
            {prompt.mediaType === "image" ? (
              <img
                src={prompt.mediaUrl}
                alt={prompt.title}
                className="max-h-[200px] w-full object-cover"
              />
            ) : (
              <video
                src={prompt.mediaUrl}
                controls
                className="max-h-[200px] w-full"
              />
            )}
            {prompt.mediaUrl && (
              <Button
                variant="secondary"
                size="icon"
                className="absolute top-2 right-2"
                onClick={handleDownload}
              >
                <Download className="h-4 w-4" />
              </Button>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <div className="flex gap-2 flex-wrap">
          {prompt.tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="hover:bg-secondary/80">
              {tag}
            </Badge>
          ))}
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={copyToClipboard}
          className="opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <Copy className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}