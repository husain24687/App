import { Moon, Sun, Layout, Home, Settings, LogOut } from "lucide-react";
import { useTheme } from "@/components/theme-provider";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export function Sidebar() {
  const { theme, setTheme } = useTheme();
  const [location] = useLocation();
  const { logoutMutation } = useAuth();

  return (
    <div className="h-screen w-64 border-r bg-sidebar p-4 flex flex-col">
      <div className="flex items-center gap-2 mb-8">
        <Layout className="w-6 h-6" />
        <h1 className="text-xl font-bold">Prompt Store</h1>
      </div>

      <nav className="space-y-2">
        <Link href="/">
          <a
            className={`flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-secondary/80 ${
              location === "/" ? "bg-secondary" : ""
            }`}
          >
            <Home className="w-5 h-5" />
            Home
          </a>
        </Link>
        <Link href="/settings">
          <a
            className={`flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-secondary/80 ${
              location === "/settings" ? "bg-secondary" : ""
            }`}
          >
            <Settings className="w-5 h-5" />
            Settings
          </a>
        </Link>
      </nav>

      <div className="mt-auto space-y-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === "light" ? "dark" : "light")}
        >
          {theme === "light" ? (
            <Moon className="h-5 w-5" />
          ) : (
            <Sun className="h-5 w-5" />
          )}
        </Button>
        <Button
          variant="ghost"
          className="w-full justify-start gap-2"
          onClick={() => logoutMutation.mutate()}
          disabled={logoutMutation.isPending}
        >
          <LogOut className="w-5 h-5" />
          {logoutMutation.isPending ? "Logging out..." : "Logout"}
        </Button>
      </div>
    </div>
  );
}