import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { insertPromptSchema, type InsertPrompt, type Prompt } from "@shared/schema";
import { useState } from "react";
import { Image, Video, X } from "lucide-react";

interface CreatePromptProps {
  existingPrompt?: Prompt;
  onClose?: () => void;
}

export function CreatePrompt({ existingPrompt, onClose }: CreatePromptProps) {
  const { toast } = useToast();
  const isEditing = !!existingPrompt;
  const [previewUrl, setPreviewUrl] = useState<string | null>(existingPrompt?.mediaUrl || null);

  const form = useForm<InsertPrompt>({
    resolver: zodResolver(insertPromptSchema),
    defaultValues: existingPrompt ?? {
      title: "",
      content: "",
      tags: [],
      mediaType: undefined,
      mediaUrl: undefined,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertPrompt) => {
      if (isEditing) {
        await apiRequest("PATCH", `/api/prompts/${existingPrompt.id}`, data);
      } else {
        await apiRequest("POST", "/api/prompts", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prompts"] });
      toast({
        title: `Prompt ${isEditing ? "updated" : "created"}`,
        description: `The prompt has been successfully ${
          isEditing ? "updated" : "created"
        }.`,
      });
      onClose?.();
      form.reset();
    },
  });

  const onSubmit = (data: InsertPrompt) => {
    const formattedTags = data.tags.map((tag) => tag.trim()).filter(Boolean);
    mutation.mutate({ ...data, tags: formattedTags });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Create a temporary preview URL
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);

    try {
      // Here you would typically upload the file to a storage service
      // For now, we'll just use a placeholder URL
      const mediaUrl = objectUrl; // Replace with actual upload URL
      form.setValue("mediaUrl", mediaUrl);
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload media file. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <DialogContent className="sm:max-w-[600px]">
      <DialogHeader>
        <DialogTitle>{isEditing ? "Edit Prompt" : "Create New Prompt"}</DialogTitle>
      </DialogHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Title</FormLabel>
                <FormControl>
                  <Input placeholder="Enter prompt title" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="content"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Content</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Enter your prompt text here..."
                    className="min-h-[100px]"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="mediaType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Media Type</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select media type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="image">
                      <div className="flex items-center gap-2">
                        <Image className="w-4 h-4" />
                        Image
                      </div>
                    </SelectItem>
                    <SelectItem value="video">
                      <div className="flex items-center gap-2">
                        <Video className="w-4 h-4" />
                        Video
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {form.watch("mediaType") && (
            <div className="space-y-2">
              <FormLabel>Upload {form.watch("mediaType")}</FormLabel>
              <Input
                type="file"
                accept={form.watch("mediaType") === "image" ? "image/*" : "video/*"}
                onChange={handleFileChange}
                className="cursor-pointer"
              />
              {previewUrl && (
                <div className="relative mt-2 rounded-lg overflow-hidden">
                  {form.watch("mediaType") === "image" ? (
                    <img
                      src={previewUrl}
                      alt="Preview"
                      className="max-h-[200px] object-contain"
                    />
                  ) : (
                    <video
                      src={previewUrl}
                      controls
                      className="max-h-[200px] w-full"
                    />
                  )}
                  <Button
                    type="button"
                    variant="destructive"
                    size="icon"
                    className="absolute top-2 right-2"
                    onClick={() => {
                      setPreviewUrl(null);
                      form.setValue("mediaUrl", undefined);
                      form.setValue("mediaType", undefined);
                    }}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>
          )}

          <FormField
            control={form.control}
            name="tags"
            render={({ field: { onChange, value, ...field } }) => (
              <FormItem>
                <FormLabel>Tags</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Enter tags separated by commas"
                    {...field}
                    value={value.join(", ")}
                    onChange={(e) =>
                      onChange(
                        e.target.value
                          .split(",")
                          .map((tag) => tag.trim())
                          .filter(Boolean)
                      )
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onClose?.()}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </Form>
    </DialogContent>
  );
}