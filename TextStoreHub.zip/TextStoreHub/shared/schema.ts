import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const prompts = pgTable("prompts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  tags: text("tags").array().notNull(),
  mediaType: text("media_type"),  // 'image' or 'video' or null
  mediaUrl: text("media_url"),    // URL to the uploaded media
  userId: serial("user_id").references(() => users.id),  // Making it nullable for now
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// For the prompts table
export const insertPromptSchema = createInsertSchema(prompts, {
  title: z.string().min(1, "Title is required").max(100),
  content: z.string().min(1, "Prompt content is required"),
  tags: z.array(z.string()).min(1, "At least one tag is required"),
  mediaType: z.enum(["image", "video"]).optional(),
  mediaUrl: z.string().url().optional(),
  userId: z.number().optional(),
}).omit({ id: true, createdAt: true });

// For the users table
export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true })
  .extend({
    username: z.string().min(3, "Username must be at least 3 characters").max(50),
    password: z.string().min(6, "Password must be at least 6 characters"),
  });

export type InsertPrompt = z.infer<typeof insertPromptSchema>;
export type Prompt = typeof prompts.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;